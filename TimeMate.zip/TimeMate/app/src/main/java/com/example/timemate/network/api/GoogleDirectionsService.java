package com.example.timemate.network.api;

import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 구글 Maps Directions API를 사용한 경로 검색 서비스
 */
public class GoogleDirectionsService {
    private static final String TAG = "GoogleDirectionsService";
    private static final String API_KEY = "AIzaSyBKadkYxtlgMaxgWL0hwrTSgL6s8wYzF28";
    private static final String BASE_URL = "https://maps.googleapis.com/maps/api/directions/json";
    
    private ExecutorService executor;
    
    public GoogleDirectionsService() {
        executor = Executors.newCachedThreadPool();
    }
    
    /**
     * 경로 검색 결과 콜백 인터페이스
     */
    public interface DirectionsCallback {
        void onSuccess(List<RouteResult> routes);
        void onError(String error);
    }
    
    /**
     * 경로 검색 결과 클래스
     */
    public static class RouteResult {
        public String mode;           // 교통수단 (driving, transit, walking, bicycling)
        public String modeIcon;       // 교통수단 아이콘
        public String modeName;       // 교통수단 이름
        public String distance;       // 거리
        public String duration;       // 소요시간
        public String cost;          // 예상 비용
        public String description;    // 경로 설명
        public boolean isRecommended; // 추천 경로 여부
        public int priority;         // 우선순위
        
        public RouteResult(String mode, String modeIcon, String modeName, 
                          String distance, String duration, String cost, String description) {
            this.mode = mode;
            this.modeIcon = modeIcon;
            this.modeName = modeName;
            this.distance = distance;
            this.duration = duration;
            this.cost = cost;
            this.description = description;
            this.isRecommended = false;
            this.priority = 3;
        }
    }
    
    /**
     * 다중 교통수단 경로 검색
     */
    public void getMultiModalRoutes(String origin, String destination, DirectionsCallback callback) {
        executor.execute(() -> {
            try {
                List<RouteResult> allRoutes = new ArrayList<>();
                
                // 1. 자동차 경로
                RouteResult drivingRoute = getRouteForMode(origin, destination, "driving");
                if (drivingRoute != null) {
                    drivingRoute.priority = 1;
                    drivingRoute.isRecommended = true;
                    allRoutes.add(drivingRoute);
                }
                
                // 2. 대중교통 경로
                RouteResult transitRoute = getRouteForMode(origin, destination, "transit");
                if (transitRoute != null) {
                    transitRoute.priority = 2;
                    allRoutes.add(transitRoute);
                }
                
                // 3. 도보 경로
                RouteResult walkingRoute = getRouteForMode(origin, destination, "walking");
                if (walkingRoute != null) {
                    transitRoute.priority = 4;
                    allRoutes.add(walkingRoute);
                }
                
                // 4. 자전거 경로
                RouteResult bicyclingRoute = getRouteForMode(origin, destination, "bicycling");
                if (bicyclingRoute != null) {
                    bicyclingRoute.priority = 3;
                    allRoutes.add(bicyclingRoute);
                }
                
                // 5. 택시 경로 (자동차 경로 기반으로 비용 계산)
                if (drivingRoute != null) {
                    RouteResult taxiRoute = createTaxiRoute(drivingRoute);
                    taxiRoute.priority = 2;
                    allRoutes.add(taxiRoute);
                }
                
                if (allRoutes.isEmpty()) {
                    callback.onError("경로를 찾을 수 없습니다");
                } else {
                    // 우선순위별 정렬
                    allRoutes.sort((a, b) -> Integer.compare(a.priority, b.priority));
                    callback.onSuccess(allRoutes);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "경로 검색 오류", e);
                callback.onError("경로 검색 중 오류가 발생했습니다: " + e.getMessage());
            }
        });
    }
    
    /**
     * 특정 교통수단으로 경로 검색
     */
    private RouteResult getRouteForMode(String origin, String destination, String mode) {
        try {
            String url = buildDirectionsUrl(origin, destination, mode);
            String response = makeHttpRequest(url);
            
            if (response != null) {
                return parseDirectionsResponse(response, mode);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "경로 검색 오류 (" + mode + ")", e);
        }
        
        return null;
    }
    
    /**
     * Directions API URL 생성
     */
    private String buildDirectionsUrl(String origin, String destination, String mode) throws Exception {
        StringBuilder url = new StringBuilder(BASE_URL);
        url.append("?origin=").append(URLEncoder.encode(origin, "UTF-8"));
        url.append("&destination=").append(URLEncoder.encode(destination, "UTF-8"));
        url.append("&mode=").append(mode);
        url.append("&language=ko");
        url.append("&region=kr");
        url.append("&key=").append(API_KEY);
        
        // 대중교통의 경우 현재 시간 기준
        if ("transit".equals(mode)) {
            long currentTime = System.currentTimeMillis() / 1000;
            url.append("&departure_time=").append(currentTime);
        }
        
        return url.toString();
    }
    
    /**
     * HTTP 요청 실행
     */
    private String makeHttpRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(10000);
        
        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            
            return response.toString();
        } else {
            Log.e(TAG, "HTTP 요청 실패: " + responseCode);
            return null;
        }
    }
    
    /**
     * Directions API 응답 파싱
     */
    private RouteResult parseDirectionsResponse(String response, String mode) {
        try {
            JSONObject json = new JSONObject(response);
            String status = json.getString("status");
            
            if (!"OK".equals(status)) {
                Log.w(TAG, "Directions API 상태: " + status);
                return null;
            }
            
            JSONArray routes = json.getJSONArray("routes");
            if (routes.length() == 0) {
                return null;
            }
            
            JSONObject route = routes.getJSONObject(0);
            JSONArray legs = route.getJSONArray("legs");
            JSONObject leg = legs.getJSONObject(0);
            
            // 거리와 시간 추출
            JSONObject distance = leg.getJSONObject("distance");
            JSONObject duration = leg.getJSONObject("duration");
            
            String distanceText = distance.getString("text");
            String durationText = duration.getString("text");
            int durationValue = duration.getInt("value"); // 초 단위
            
            // 교통수단별 정보 설정
            String modeIcon = getModeIcon(mode);
            String modeName = getModeName(mode);
            String cost = calculateCost(mode, distance.getInt("value"), durationValue);
            String description = leg.getString("start_address") + " → " + leg.getString("end_address");
            
            return new RouteResult(mode, modeIcon, modeName, distanceText, durationText, cost, description);
            
        } catch (Exception e) {
            Log.e(TAG, "응답 파싱 오류", e);
            return null;
        }
    }
    
    /**
     * 교통수단별 아이콘 반환
     */
    private String getModeIcon(String mode) {
        switch (mode) {
            case "driving": return "🚗";
            case "transit": return "🚌";
            case "walking": return "🚶";
            case "bicycling": return "🚴";
            default: return "🗺️";
        }
    }
    
    /**
     * 교통수단별 이름 반환
     */
    private String getModeName(String mode) {
        switch (mode) {
            case "driving": return "자동차";
            case "transit": return "대중교통";
            case "walking": return "도보";
            case "bicycling": return "자전거";
            default: return "기타";
        }
    }
    
    /**
     * 교통수단별 비용 계산
     */
    private String calculateCost(String mode, int distanceMeters, int durationSeconds) {
        double distanceKm = distanceMeters / 1000.0;
        
        switch (mode) {
            case "driving":
                // 연료비 + 통행료 (대략 km당 300원)
                int drivingCost = (int) (distanceKm * 300);
                return String.format("%,d원", drivingCost);
                
            case "transit":
                // 대중교통비 (기본 1,500원 + 거리별 추가)
                int transitCost = 1500;
                if (distanceKm > 10) transitCost += (int) ((distanceKm - 10) * 100);
                return String.format("%,d원", transitCost);
                
            case "walking":
            case "bicycling":
                return "무료";
                
            default:
                return "미정";
        }
    }
    
    /**
     * 택시 경로 생성 (자동차 경로 기반)
     */
    private RouteResult createTaxiRoute(RouteResult drivingRoute) {
        // 택시 요금 계산 (기본료 + 거리비 + 시간비)
        String distanceStr = drivingRoute.distance.replaceAll("[^0-9.]", "");
        double distance = 0;
        try {
            distance = Double.parseDouble(distanceStr);
        } catch (NumberFormatException e) {
            distance = 5.0; // 기본값
        }
        
        // 택시 요금 계산 (서울 기준)
        int baseFare = 4800; // 기본료
        int distanceFare = (int) (Math.max(0, distance - 2) * 100 * 10); // 2km 초과분
        int totalFare = baseFare + distanceFare;
        
        return new RouteResult(
            "taxi", "🚕", "택시",
            drivingRoute.distance,
            drivingRoute.duration,
            String.format("%,d원", totalFare),
            drivingRoute.description.replace("자동차", "택시")
        );
    }
    
    /**
     * 서비스 종료
     */
    public void shutdown() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }
}
