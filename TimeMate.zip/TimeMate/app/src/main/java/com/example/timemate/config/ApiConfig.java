package com.example.timemate.config;

import com.example.timemate.BuildConfig;

/**
 * API 설정 관리 클래스
 * gradle.properties에서 설정된 값들을 안전하게 관리
 */
public class ApiConfig {

    // 네이버 클라우드 플랫폼 API 인증 정보
    public static final String NAVER_CLOUD_CLIENT_ID = BuildConfig.NAVER_CLOUD_CLIENT_ID;
    public static final String NAVER_CLOUD_CLIENT_SECRET = BuildConfig.NAVER_CLOUD_CLIENT_SECRET;

    // 네이버 개발자 센터 API 인증 정보
    public static final String NAVER_DEV_CLIENT_ID = BuildConfig.NAVER_DEV_CLIENT_ID;
    public static final String NAVER_DEV_CLIENT_SECRET = BuildConfig.NAVER_DEV_CLIENT_SECRET;

    // OpenWeather API 인증 정보
    public static final String OPENWEATHER_API_KEY = BuildConfig.OPENWEATHER_API_KEY;

    // 카카오 API 인증 정보
    public static final String KAKAO_REST_API_KEY = "5de756b82319d0e5cc12ebcbad5a8a74";

    // 네이버 클라우드 플랫폼 API 엔드포인트
    public static final String NAVER_STATIC_MAP_URL = BuildConfig.NAVER_STATIC_MAP_URL;
    public static final String NAVER_DIRECTIONS_URL = BuildConfig.NAVER_DIRECTIONS_URL;
    public static final String NAVER_GEOCODING_URL = BuildConfig.NAVER_GEOCODING_URL;
    public static final String NAVER_REVERSE_GEOCODING_URL = BuildConfig.NAVER_REVERSE_GEOCODING_URL;
    public static final String NAVER_LOCAL_SEARCH_URL = BuildConfig.NAVER_LOCAL_SEARCH_URL;

    // 카카오 API 엔드포인트
    public static final String KAKAO_LOCAL_SEARCH_URL = "https://dapi.kakao.com/v2/local/search/keyword.json";
    public static final String KAKAO_ADDRESS_SEARCH_URL = "https://dapi.kakao.com/v2/local/search/address.json";
    public static final String KAKAO_COORD_TO_ADDRESS_URL = "https://dapi.kakao.com/v2/local/geo/coord2address.json";

    /**
     * API 설정 유효성 검사
     */
    public static boolean isConfigValid() {
        return !NAVER_CLOUD_CLIENT_ID.isEmpty() &&
               !NAVER_CLOUD_CLIENT_SECRET.isEmpty() &&
               !NAVER_DEV_CLIENT_ID.isEmpty() &&
               !NAVER_DEV_CLIENT_SECRET.isEmpty() &&
               !OPENWEATHER_API_KEY.isEmpty() &&
               !KAKAO_REST_API_KEY.isEmpty();
    }

    /**
     * 네이버 클라우드 플랫폼 API 설정 유효성 검사
     */
    public static boolean isNaverCloudConfigValid() {
        return !NAVER_CLOUD_CLIENT_ID.isEmpty() &&
               !NAVER_CLOUD_CLIENT_SECRET.isEmpty();
    }

    /**
     * 네이버 개발자 센터 API 설정 유효성 검사
     */
    public static boolean isNaverDevConfigValid() {
        return !NAVER_DEV_CLIENT_ID.isEmpty() &&
               !NAVER_DEV_CLIENT_SECRET.isEmpty();
    }

    /**
     * OpenWeather API 설정 유효성 검사
     */
    public static boolean isOpenWeatherConfigValid() {
        return !OPENWEATHER_API_KEY.isEmpty();
    }

    /**
     * 카카오 API 설정 유효성 검사
     */
    public static boolean isKakaoConfigValid() {
        return !KAKAO_REST_API_KEY.isEmpty() &&
               !KAKAO_REST_API_KEY.equals("YOUR_KAKAO_REST_API_KEY");
    }

    /**
     * 디버그용 설정 정보 출력 (보안키는 마스킹)
     */
    public static String getConfigInfo() {
        return "API Config Info:\n" +
               "- Naver Cloud ID: " + maskApiKey(NAVER_CLOUD_CLIENT_ID) + "\n" +
               "- Naver Dev ID: " + maskApiKey(NAVER_DEV_CLIENT_ID) + "\n" +
               "- OpenWeather Key: " + maskApiKey(OPENWEATHER_API_KEY) + "\n" +
               "- Kakao REST Key: " + maskApiKey(KAKAO_REST_API_KEY) + "\n" +
               "- Static Map URL: " + NAVER_STATIC_MAP_URL + "\n" +
               "- Directions URL: " + NAVER_DIRECTIONS_URL + "\n" +
               "- Geocoding URL: " + NAVER_GEOCODING_URL;
    }

    /**
     * API 키 마스킹 (보안을 위해 일부만 표시)
     */
    private static String maskApiKey(String apiKey) {
        if (apiKey == null || apiKey.length() < 8) {
            return "****";
        }
        return apiKey.substring(0, 4) + "****" + apiKey.substring(apiKey.length() - 4);
    }
}
