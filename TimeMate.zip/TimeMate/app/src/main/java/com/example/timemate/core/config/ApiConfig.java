package com.example.timemate.core.config;

import com.example.timemate.BuildConfig;

/**
 * API 설정 중앙 관리 클래스
 * 모든 API 키와 엔드포인트를 안전하게 관리
 */
public class ApiConfig {

    // 네이버 클라우드 플랫폼 API 인증 정보
    public static final String NAVER_CLOUD_CLIENT_ID = BuildConfig.NAVER_CLOUD_CLIENT_ID;
    public static final String NAVER_CLOUD_CLIENT_SECRET = BuildConfig.NAVER_CLOUD_CLIENT_SECRET;

    // 네이버 개발자 센터 API 인증 정보
    public static final String NAVER_DEV_CLIENT_ID = BuildConfig.NAVER_DEV_CLIENT_ID;
    public static final String NAVER_DEV_CLIENT_SECRET = BuildConfig.NAVER_DEV_CLIENT_SECRET;

    // OpenWeather API 인증 정보
    public static final String OPENWEATHER_API_KEY = BuildConfig.OPENWEATHER_API_KEY;

    // 네이버 클라우드 플랫폼 API 엔드포인트
    public static final String NAVER_STATIC_MAP_URL = BuildConfig.NAVER_STATIC_MAP_URL;
    public static final String NAVER_DIRECTIONS_URL = BuildConfig.NAVER_DIRECTIONS_URL;
    public static final String NAVER_GEOCODING_URL = BuildConfig.NAVER_GEOCODING_URL;
    public static final String NAVER_REVERSE_GEOCODING_URL = BuildConfig.NAVER_REVERSE_GEOCODING_URL;

    // 네이버 개발자 센터 API 엔드포인트
    public static final String NAVER_LOCAL_SEARCH_URL = BuildConfig.NAVER_LOCAL_SEARCH_URL;

    // OpenWeather API 엔드포인트
    public static final String OPENWEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5/";

    /**
     * API 설정 유효성 검사
     */
    public static boolean isConfigValid() {
        return isNaverCloudConfigValid() && 
               isNaverDevConfigValid() && 
               isOpenWeatherConfigValid();
    }

    /**
     * 네이버 클라우드 플랫폼 API 설정 유효성 검사
     */
    public static boolean isNaverCloudConfigValid() {
        return !NAVER_CLOUD_CLIENT_ID.isEmpty() &&
               !NAVER_CLOUD_CLIENT_SECRET.isEmpty() &&
               !NAVER_STATIC_MAP_URL.isEmpty() &&
               !NAVER_DIRECTIONS_URL.isEmpty() &&
               !NAVER_GEOCODING_URL.isEmpty() &&
               !NAVER_REVERSE_GEOCODING_URL.isEmpty();
    }

    /**
     * 네이버 개발자 센터 API 설정 유효성 검사
     */
    public static boolean isNaverDevConfigValid() {
        return !NAVER_DEV_CLIENT_ID.isEmpty() &&
               !NAVER_DEV_CLIENT_SECRET.isEmpty() &&
               !NAVER_LOCAL_SEARCH_URL.isEmpty();
    }

    /**
     * OpenWeather API 설정 유효성 검사
     */
    public static boolean isOpenWeatherConfigValid() {
        return !OPENWEATHER_API_KEY.isEmpty();
    }

    /**
     * 디버그용 설정 정보 출력 (보안키는 마스킹)
     */
    public static String getConfigInfo() {
        return "API Config Info:\n" +
               "- Naver Cloud Valid: " + isNaverCloudConfigValid() + "\n" +
               "- Naver Dev Valid: " + isNaverDevConfigValid() + "\n" +
               "- OpenWeather Valid: " + isOpenWeatherConfigValid() + "\n" +
               "- Naver Cloud ID: " + maskApiKey(NAVER_CLOUD_CLIENT_ID) + "\n" +
               "- Naver Dev ID: " + maskApiKey(NAVER_DEV_CLIENT_ID) + "\n" +
               "- OpenWeather Key: " + maskApiKey(OPENWEATHER_API_KEY) + "\n" +
               "- Static Map URL: " + NAVER_STATIC_MAP_URL + "\n" +
               "- Directions URL: " + NAVER_DIRECTIONS_URL + "\n" +
               "- Local Search URL: " + NAVER_LOCAL_SEARCH_URL;
    }

    /**
     * API 키 마스킹 (보안을 위해 일부만 표시)
     */
    private static String maskApiKey(String apiKey) {
        if (apiKey == null || apiKey.length() < 8) {
            return "****";
        }
        return apiKey.substring(0, 4) + "****" + apiKey.substring(apiKey.length() - 4);
    }

    /**
     * 환경별 설정
     */
    public static class Environment {
        public static final boolean IS_DEBUG = BuildConfig.DEBUG;
        public static final String APP_VERSION = BuildConfig.VERSION_NAME;
        public static final int APP_VERSION_CODE = BuildConfig.VERSION_CODE;
        
        public static boolean isProduction() {
            return !IS_DEBUG;
        }
        
        public static String getUserAgent() {
            return "TimeMate/" + APP_VERSION + " (Android)";
        }
    }

    /**
     * 네트워크 설정
     */
    public static class Network {
        public static final int CONNECT_TIMEOUT_SECONDS = 10;
        public static final int READ_TIMEOUT_SECONDS = 30;
        public static final int WRITE_TIMEOUT_SECONDS = 30;
        
        // 재시도 설정
        public static final int MAX_RETRY_COUNT = 3;
        public static final long RETRY_DELAY_MS = 1000;
        
        // 캐시 설정
        public static final long CACHE_SIZE = 10 * 1024 * 1024; // 10MB
        public static final int CACHE_MAX_AGE_SECONDS = 60 * 5; // 5분
    }

    /**
     * 검색 설정
     */
    public static class Search {
        public static final int MIN_SEARCH_LENGTH = 2;
        public static final int DEBOUNCE_DELAY_MS = 300;
        public static final int MAX_SEARCH_RESULTS = 10;
        public static final int SEARCH_RADIUS_METERS = 5000;
    }

    /**
     * 일정 설정
     */
    public static class Schedule {
        public static final int REMINDER_BUFFER_MINUTES = 10;
        public static final int MAX_TITLE_LENGTH = 100;
        public static final int MAX_MEMO_LENGTH = 500;
        public static final long MAX_FUTURE_DAYS = 365; // 1년
    }
}
